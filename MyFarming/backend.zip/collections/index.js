const contractorModel = require("./contractor");
const customerModel = require("./customer");
const getbillModel = require("./getbill");
const totalbillModel = require("./totalbill");
module.exports = {
  contractorModel,
  customerModel,
  getbillModel,
  totalbillModel
};
