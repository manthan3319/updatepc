// port.js
const port = 'http://35.154.84.155:7000';
export default port;
