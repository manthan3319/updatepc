const contractorModel = require("./contractor");

module.exports = {
  contractorModel,
};
