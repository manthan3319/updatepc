const contractorModel = require("./contractor");
const festivalpostModel = require("./Festivalpost");

module.exports = {
  contractorModel,
  festivalpostModel
};
