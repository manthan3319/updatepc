/**
 * This is for Contain function layer for contractor service.
 * @author Manthan Vaghasiya
 *
 */

const ObjectId = require("mongodb").ObjectID;
const { isDate } = require("lodash");
const dbService = require("../../utilities/dbService");

/*************************** addcustomer ***************************/
const addcustomer = async (req, mainUserId, createdBy) => {

  let addcustomerData = {
    name: req.body.name,
    businessName: req.body.businessName,
    businessAdress: req.body.businessAdress,
    logoName: req.body.logoName,
    amount:req.body.amount
  }


  if (addcustomerData) {
    let project = await dbService.createOneRecord("festivalpostModel", req.body);
    return "data inserted";

  } else {
    throw new Error("Customer Data Not Insert!");
  }
};

/*************************** getFestivalpostcustomer ***************************/
const getFestivalpostcustomer = async (req, mainUserId, createdBy) => {
    let whare = {
      isDeleted:false
    }

    let getcustomerData = await dbService.findAllRecords("festivalpostModel", whare);

    if(getcustomerData){
        return{
          mess: "get Festibalpost all customer",
          Data: getcustomerData
        }
    }else{
      throw new Error("Not fatch data!");
    }
};


module.exports = {
  addcustomer,
  getFestivalpostcustomer,
};
