/*
 * @file: index.js
 * @description: It's combine all routers.
 * @author: Manthan Vaghasiya
 */
const { Router } = require("express");
const app = Router();

const contractor = require("./contractor");
const Festivalpost = require("./Festivalpost");

/*********** Combine all Routes ********************/
app.use("/contractor", contractor);
app.use("/Festivalpost", Festivalpost);

module.exports = app;
