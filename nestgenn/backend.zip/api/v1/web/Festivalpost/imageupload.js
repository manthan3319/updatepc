const { Router } = require("express");
const router = new Router();

const multer = require("multer");

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "FestivalpostLogo");
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  },
});

const upload = multer({ storage });

/**
 * @swagger
 * /api/v1/Festivalpost/addimg:
 *  post:
 *   tags: ["Festivalpost"]
 *   summary: get addimg information.
 *   description: api used for get addimg information.
 *   parameters:
 *      - in: formData
 *        name: image
 *        description: The image to upload.
 *        type: file
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */
router.post(
  "/addimg",
  upload.single("FestivalpostLogo"), // "image" should match the field name in the form data
  // decodeJwtTokenFn, // Uncomment if needed
  (req, res) => {
    // Access the uploaded file details from req.file
    const uploadedFile = req.file;

    // Check if the file exists
    if (!uploadedFile) {
      return res.status(400).json({ error: "No file uploaded." });
    }

    // File details are available in uploadedFile object
    const { filename, originalname, destination } = uploadedFile;

    // Perform any additional logic or save file details to the database

    // Send a response indicating success
    res.status(200).json({ success: true, message: "File uploaded successfully." });
  }
);

module.exports = router;
