/**
 * This is Contain Save router/api.
 * @author Manthan Vaghasiya
 *
 */

const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { getFestivalpostcustomer } = require("../../../../services/Festivalpost/Festivalpost");
const router = new Router();

/**
 * @swagger
 * /api/v1/Festivalpost/getFestivalpostcustomer:
 *  post:
 *   tags: ["Festivalpost"]
 *   summary: get Festivalpost information.
 *   description: api used for get Festivalpost information.
 *   parameters:
 *      - in: body
 *        name: lead
 *        description: get Festivalpost information.
 *        schema:
 *         type: object
 *         properties:
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 *   security:
 *      - bearerAuth: []
 */

router.post(
  "/getFestivalpostcustomer",
  commonResolver.bind({
    modelService: getFestivalpostcustomer,
  })
);

module.exports = router;
