/**
 * This is Contain Save router/api.
 * @author Manthan Vaghasiya
 *
 */

const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { addcustomer } = require("../../../../services/Festivalpost/Festivalpost");
const router = new Router();


/**
 * @swagger
 * /api/v1/Festivalpost/addcustomer:
 *  post:
 *   tags: ["Festivalpost"]
 *   summary: Save Festivalpost information.
 *   description: api used for Save Festivalpost information.
 *   parameters:
 *      - in: body
 *        name: lead
 *        description: Save Festivalpost information.
 *        schema:
 *         type: object
 *         properties:
 *           name:
 *             type: string
 *           number:
 *             type: string
 *           amount:
 *             type: string
 *           businessName:
 *             type: string
 *           businessAdress:
 *             type: string
 *           logoName:
 *             type: string
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */

const dataSchema = Joi.object({
  name: Joi.string().required().label("name"),
  number: Joi.string().required("number"),
  amount: Joi.string().required("amount"),
  businessName: Joi.string().required("businessName"),
  businessAdress: Joi.string().required("businessAdress"),
  logoName: Joi.string().required("logoName"),
});

router.post(
  "/addcustomer",
  commonResolver.bind({
    modelService: addcustomer,
    isRequestValidateRequired: true,
    schemaValidate: dataSchema,
  })
);



module.exports = router;
