/*
 * @file: index.js
 * @description: It's combine all contractor routers.
 * @author: Manthan Vaghasiya
 */

const save = require("./save");
const getFestivalpostcustomer = require("./getFestivalpostcustomer");
const edit = require("./edit");
const single = require("./single");
const deleteOne = require("./delete");
const addimg = require("./imageupload")

module.exports = [
    save,
    getFestivalpostcustomer,
    edit,
    single,
    deleteOne,
    addimg
];
