import React from 'react'
import HealthyFood from '../HealthyFood/HealthyFood.js';
import ProvideFood from '../ProvideFood/ProvideFood';
import Menuitem from '../Menuitem/Menuitem.js';
const Dashbord = () => {

 
  return (
    <>
      <HealthyFood />
      <ProvideFood/>
      <Menuitem/>
    </>
  )
}

export default Dashbord
