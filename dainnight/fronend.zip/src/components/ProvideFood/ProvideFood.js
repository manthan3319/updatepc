import React from 'react'
import ProvideFoodimg from '../../images/ProvideFood.png'
import { Link } from 'react-router-dom'

const ProvideFood = () => {
    return (
        <div className='lg:max-w-[1440px] lg:px-[150px]'>
            <div className='flex lg:flex-row lg:mt-[100px] lg:mb-[100px] gap-[60px] text-[#808080]'>
                <div className='lg:w-[50%]'>
                  <Link> <img src={ProvideFoodimg} alt='iamge' className='' /> </Link>
                </div>
                <div className='lg:w-[50%]'>
                    <p className='text-[#FF9000] font-sans'>About Us</p>

                    <h2 className='text-[#adadad] text-[38px] font-bold leading-[45px] mb-[20px] mt-[15px]'>We Provide Food With Managing Your Time</h2>

                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown.</p>

                    <button className='text-white bg-[#FF9000] px-[16px] rounded-tl-[10px] py-[10px] rounded-tr-[2px] rounded-bl-[2px] rounded-br-[10px] font-sans text-[15px] mt-[25px]'>Our Happy Customers</button>

                </div>
            </div>
        </div>
    )
}

export default ProvideFood
