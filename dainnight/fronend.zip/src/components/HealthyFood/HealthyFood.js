import React from 'react'
import scootericon from '../../images/scooter 1.png';
import menudish from '../../images/Group 109.png';

const HealthyFood = () => {
  return (
    <div className='lg:max-w-[1440px] lg:px-[150px] lg:mt-[70px] text-[#808080] '>
      <div className='flex lg:flex-row '>

      
        <div className='lg:w-[50%] lg:mt-[70px]'>
          <p className='text-white flex items-center gap-[10px] bg-[#ff90002e] text-[13px] rounded-tl-[15px] rounded-tr-[2px]  rounded-bt-[2px] rounded-br-[15px]  mb-[10px]   font-sans px-[18px] py-[5px] w-[38%]'> <span><img src={scootericon} alt='icon' /></span> Free Delivery</p>
          <h1 className='text-[45px] mt-[15px] text-[#adadad] leading-[60px] font-sans font-bold'>Enjoy Delicious <span className='text-[#FF9000]'>&</span> <br></br> Healthy Food</h1>

          <p className='text-[12px] mt-[20px] font-sans'>McDelivery allows you to experience delicious McDonald’s food from the comfort of your sofa at home or cubicle in office. All orders are delivered quickly and efficiently, allowing you the peace of mind to know that smiles-inducing food is never too far.</p>

          <button className='text-white bg-[#FF9000] px-[16px] rounded-tl-[10px] py-[10px] rounded-tr-[2px] rounded-bl-[2px] rounded-br-[10px] font-sans text-[15px] mt-[45px]'>Order Now</button>
        </div>

        <div>
          <img src={menudish} alt='dish image' className='w-[100%]' />
        </div>
      </div>
    </div>
  )
}

export default HealthyFood
