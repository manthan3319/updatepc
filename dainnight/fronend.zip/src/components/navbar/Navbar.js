import React from 'react'
import logo from '../../images/pnglogo.png'
import { Link } from 'react-router-dom'
const Navbar = () => {
  return (
    <>
        <div className='lg:max-w-[1440px] lg:px-[150px]'>
            <div className='flex lg:flex-row justify-between items-center lg:mt-[30px] text-[#808080] '>
                  <div>
                        <img src={logo} alt='logo' className='contrast-0 w-[200px]' />
                  </div>

                  <div>
                      <ul className='text-[#808080] flex lg:flex-row gap-[35px]'>
                        <li><Link className='font-sans  hover:text-[#FF9000]'>Home</Link></li>
                        <li><Link className='font-sans  hover:text-[#FF9000]'>Menu</Link></li>
                        <li><Link className='font-sans  hover:text-[#FF9000]'>Events</Link></li>
                        <li><Link className='font-sans  hover:text-[#FF9000]'>Gallery</Link></li>
                        <li><Link className='font-sans  hover:text-[#FF9000]'>About</Link></li>
                        <li><Link className='font-sans  hover:text-[#FF9000]'>Contact</Link></li>
                      </ul>
                  </div>

                  <div>
                    <button className='text-white bg-[#FF9000] px-[16px] rounded-tl-[10px] py-[10px] rounded-tr-[2px] rounded-bl-[2px] rounded-br-[10px] font-sans text-[15px]'>Book a table </button>
                  </div>
            </div>
        </div>
    </>
  )
}

export default Navbar
