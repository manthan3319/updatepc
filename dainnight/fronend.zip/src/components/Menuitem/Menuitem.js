import React from 'react';
import menu1 from '../../images/menu-3 1.png';
import menu2 from '../../images/menu-6 1.png';
import menu3 from '../../images/menu-3 1.png';
import menu4 from '../../images/menu-4 1.png';
import menu5 from '../../images/menu-5 1.png';
const Menuitem = () => {
  const PremiumMenu = [
    {
      'id': 1,
      'name': "Spicy seasoned seafood noodles",
      'image': menu1,
      'price': "2.29",
      'descrip': "20 Bowls available"
    },
    {
      'id': 2,
      'name': "Salted Pasta with mushroom sauce",
      'image': menu2,
      'price': "2.69",
      'descrip': "15 Bowls available"
    },
    {
      'id': 2,
      'name': "Salted Pasta with mushroom sauce",
      'image': menu3,
      'price': "2.69",
      'descrip': "15 Bowls available"
    },
    {
      'id': 2,
      'name': "Salted Pasta with mushroom sauce",
      'image': menu4,
      'price': "2.69",
      'descrip': "15 Bowls available"
    },
    {
      'id': 2,
      'name': "Salted Pasta with mushroom sauce",
      'image': menu5,
      'price': "2.69",
      'descrip': "15 Bowls available"
    }
    // Add more menu items as needed
  ];

  return (
    <div className='lg:max-w-[1440px] lg:px-[150px] mx-auto py-8'>
      <div className='text-center mb-[45px]'>
        <p className='text-[#FF9000] inline-block border-b-[2px] pb-[2px] border-[#FF9000] font-semibold font-sans text-[18px]'>
          Premium Menu
        </p>
      </div>

      <div className='flex gap-[25px] mt-[100px]'>
        {PremiumMenu.map(item => (
          <div key={item.id} className='bg-[#ff900061] p-4 lg:w-[19%] rounded-lg relative menu-item'>
            <div className='flex justify-center mb-4'>
              <img src={item.image} alt={item.name} className='w-[120px] -top-[50px] h-[120px] object-cover rounded-[50%] absolute' />
            </div>
            <div className='text-center pt-[60px] '>
              <h2 className='text-white font-semibold font-sans mb-[15px] text-[16px]'>{item.name}</h2>
              <p className='text-white mb-2 font-sans '>${item.price}</p>
              <p className='text-white text-[14px] font-sans'>{item.descrip}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Menuitem;
