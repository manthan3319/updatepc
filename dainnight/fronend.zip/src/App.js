import React, { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';

const Dashbord = lazy(() => import('./components/Dashbord/Dashbord.js'));
const Navbar = lazy(() => import('./components/navbar/Navbar.js'));

const App = () => {
  return (
    <React.Fragment>
      <Suspense fallback={<div>Loading...</div>}>
        <Navbar />
        <Routes>
          <Route path="/" element={<Dashbord />} />
        </Routes>
      </Suspense>
    </React.Fragment>
  );
};

export default App;
