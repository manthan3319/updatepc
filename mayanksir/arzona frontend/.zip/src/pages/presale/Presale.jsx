import React from "react";
import background from "../../assets/arzpresale.png";
import "../../styles/Presale.css";
import logo from "../../assets/arzonalogo.png";
import usdt from "../../assets/usdt1.svg";
import { Link } from "react-router-dom";

const Presale = () => {
  return (
    <>
      <div className="presale">
        <div className="topbar">
          <Link to="/">
            {" "}
            <img src={logo} alt="" />
          </Link>
          <a
            type="button"
            style={{
              backgroundColor: "#43419D",
              height: 40,
              textDecoration: "none",
              cursor: "pointer",
            }}
            class="text-white  hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-full text-sm px-8 py-2 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
          >
            Connect Wallet
          </a>
        </div>

        <div className="presalecontent">
          <p className="presalehead">
            Unlock Early Access: Join Our Exclusive{" "}
            <span className="prespan">Presale</span> Now!
          </p>

          <div className="countdown">
            <div className="countdown1">
              <p className="countnumber">03</p>
              <p className="countname">Days</p>
            </div>
            <div className="countdown1">
              <p className="countnumber">03</p>
              <p className="countname">Hours</p>
            </div>
            <div className="countdown1">
              <p className="countnumber">03</p>
              <p className="countname">Minutes</p>
            </div>
            <div className="countdown1">
              <p className="countnumber">03</p>
              <p className="countname">Seconds</p>
            </div>
          </div>

          <div className="phase">
            <div className="phase01">Round 1</div>
            <div className="phase02">Round 2</div>
            <div className="phase02">Round 3</div>
            <div className="phase02">Round 4</div>
            <div className="phase02">Round 5</div>
            <div className="phase02">Round 6</div>
          </div>
          <div className="predata">
            <p className="presmallhead">Current Sold Tokens</p>
            <p className="presmallhead"> 25,000,000</p>
          </div>
          <div class="progress">
            <div class="progress-value"></div>
          </div>

          <div className="bn">
            <p className="presmallhead">Buy With</p>
            <div className="buyinput">
              <div className="preimg">
                <img src={usdt} alt="" />
              </div>
              <input
                type="text"
                id="Amount"
                className="bg-white border border-gray-300 text-lg text-gray-900   rounded-lg  block w-full   "
                placeholder="Enter Amount"
                required
              />
            </div>
          </div>
          <div className="bn">
            <p className="presmallhead">You will get</p>
            <div className="buyinput">
              <div className="preimg">
                <img src="/icon2.png" alt="" />
              </div>
              <input
                type="text"
                id="Amount"
                className="bg-white border border-gray-300 text-lg text-gray-900   rounded-lg  block w-full   "
                placeholder="Arzona Token"
                required
              />
            </div>
          </div>
          <a className="presubmit">Buy tokens</a>
        </div>
      </div>
    </>
  );
};

export default Presale;
