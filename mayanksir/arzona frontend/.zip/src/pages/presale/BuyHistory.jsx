import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../../styles/Dashboard.css";
import logo from "../../assets/arzlogo.png";
import user from "../../assets/user.png";
import copyBtn from "../../assets/copy.png";
import menu from "../../assets/menu.svg";
import axios from 'axios';
import { useAccount } from "wagmi";
import './globle.css'
const BuyHistory = () => {
  const [isActive, setIsActive] = useState(false);
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState([]);
  const { isConnected, address } = useAccount();
  
//   const [userData, setUserData] = useState([]);
//   useEffect(() => {
//     const fetchUserData = async () => {
//         try {
//             const token = localStorage.getItem('token');
//             const response = await axios.get('http://localhost:3300/api/user', {
//                 headers: {
//                     'Authorization': `Bearer ${token}`
//                 }
//             });
//             setUserData(response.data);
//             setLoading(false);
//         } catch (error) {
//             console.error('Error fetching user data:', error);
//             setLoading(false);
//         }
//     };
//     fetchUserData();
// }, []);


useEffect(() => {
  if (isConnected) {
    axios.post('http://localhost:3300/api/buyss', {
      // walletAddress: address
      walletAddress: "0x2146a17Aa9Ec3219e00b902b0BD6683ac95f7564"
    })
      .then(response => {
        // console.log("Response data:", response.data);
        setData(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching buy history:', error);
        setLoading(false);
      });
  } else {
    setLoading(false);
  }
}, [isConnected, address]);

  // useEffect(() => {
  //   const token = localStorage.getItem('token');
  //   if (!token) {
  //     navigate('/login');
  //     return;
  //   }

  //   axios.get('http://localhost:3300/api/buys', {
  //     headers: {
  //       'Authorization': `Bearer ${token}`
  //     }
  //   })
  //   .then(response => {
  //     setData(response.data);
  //     setLoading(false);
  //   })
  //   .catch(error => {
  //     console.error('There was an error fetching the data!', error);
  //     setLoading(false);
  //   });
  // }, [navigate]);

  const toggleSidebar = () => {
    setIsActive(!isActive);
  };

  // const currentUserData = data.filter(item => item.userId === userData.userId);
  // const indexOfLastItem = currentPage * itemsPerPage;
  // const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  // const currentItems = currentUserData.slice(indexOfFirstItem, indexOfLastItem);

  // const paginate = (pageNumber) => setCurrentPage(pageNumber);

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text).then(() => {
      alert('Referral code copied to clipboard!');
    }, (err) => {
      console.error('Could not copy text: ', err);
    });
  };


  const TableData = {
    buyList: data,

  };

  // console.log(data)

  const [currentTableData, setCurrentTableData] = useState('buyList');


  const totalPages = Math.ceil(TableData[currentTableData].length / itemsPerPage);

  const getCurrentPageTableData = () => {
    const TableDataset = TableData[currentTableData];
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return TableDataset.slice(startIndex, endIndex);
  };

  const handleSwitchTableData = (type) => {
    setCurrentTableData(type);
    setCurrentPage(1);
  };

  const handlePageClick = (pageNumber) => {
    if (pageNumber !== "...") {
      setCurrentPage(pageNumber);
    }
  };

  const createPagination = () => {
    const pageNumbers = [];
    const visibleRange = 3;

    pageNumbers.push(1);

    if (totalPages <= visibleRange) {
      for (let i = 2; i <= totalPages; i++) {
        pageNumbers.push(i);
      }
    } else {
      let startRange = Math.max(2, currentPage - 1);
      let endRange = Math.min(totalPages - 1, currentPage + 1);

      if (startRange > 2) {
        pageNumbers.push('...');
      }

      for (let i = startRange; i <= endRange; i++) {
        pageNumbers.push(i);
      }

      if (endRange < totalPages - 1) {
        pageNumbers.push('...');
      }

      if (totalPages > 1) {
        pageNumbers.push(totalPages);
      }
    }

    return pageNumbers;
  };

  const currentPageTableData = getCurrentPageTableData();

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="main-container">
<div className="wrapper">
        <nav id="sidebar" className={`sidebar ${isActive ? "active" : ""}`}>
          <div className="sidebar-header">
            <img src={logo} alt="" />
            <p className="username"></p>
          </div>

          <ul className="list-unstyled components">
            <div className="user" style={{ paddingBottom: 20 }}>
              <div className="circle">
                <img src={user} className="spec22" alt="" />
              </div>
              <p className="username"></p>
            </div>
            <li className="active">
              <a
                href="/dashboard"
                data-toggle="collapse"
                aria-expanded="false"
                className="dropdown-toggle"
              >
                Dashboard
              </a>
            </li>

            <li>
              <a
                href="/buyhistory"
                data-toggle="collapse"
                aria-expanded="false"
                className="dropdown-toggle"
              >
                Buy History
              </a>
            </li>
            <li>
              <a href="/referralhistory"> Referral History</a>
            </li>
            <li>
              <a href="https://arzona-whitepaper.gitbook.io/arzona-whitepaper/">Whitepaper</a>
            </li>
            <li>
              <a href="#">Contract</a>
            </li>
            <li>
              {/* <a href="#">Setting</a> */}
            </li>
            <li>
              {!localStorage.getItem("token") ? (
                <div className="flex gap-4">
                  <Link
                    to={"/login"}
                    className="leading-3 p-3 bg-[#F9DA0A] rounded-md text-[#000000] font-semibold"
                  >
                    Login
                  </Link>
                  <Link
                    to={"/signup"}
                    className="leading-3 p-3 rounded-md bg-[#8484848A] text-white font-semibold"
                  >
                    Sign up
                  </Link>
                </div>
              ) : (
                <button
                  onClick={() => {
                    localStorage.clear();
                    window.location.reload();
                  }}
                  className="leading-3 p-3 rounded-md bg-[#8484848A] text-white font-semibold"
                >
                  Logout
                </button>
              )}
            </li>
          </ul>
        </nav>

        <div id="content">
          <button
            id="sidebarCollapse"
            onClick={toggleSidebar}
            style={{ backgroundColor: "black" }}
          >
            <img src={menu} alt="" />
          </button>
          <br />
          <div className="content1">
            <div className="content01">
              <p className="chead">Welcome to Arzona Staking.</p>
              <p className="cpara">
                Second Round is about to start. Let’s explore it.
              </p>
            </div>
          </div>
          <br />
          <br />


          <div id="ref-main" className=" my-10 ">
            <div className="mb-4  space-x-5 px-20 tablet:px-5 tablet:space-x-2 ">
              <button
                onClick={() => handleSwitchTableData('buyList')}
                className={` px-3 py-1 
                     ${currentTableData === 'buyList' ? 'bg-gradient' : 'bg-gray-700'}
                      text-white rounded-3xl `}
              >
                Buy History
              </button>
              {/* <button
                    onClick={() => handleSwitchTableData('Refral')}
                    className={`px-3 py-1
                     ${currentTableData === 'Refral' ? 'bg-gradient' : 'bg-gray-700'}
                      text-white rounded-3xl`}
                >
                    Stake
                </button> */}
            </div>
            <div className='px-20 tablet:px-5 ' >
              <div className="relative overflow-x-auto shadow-md  rounded-lg">
                <table className="w-full text-sm text-left text-gray-300">
                  <thead className="text-xs text-gray-200 uppercase bg-gray-800">
                    <tr className='font-bold text-sm tracking-wider' >
                      <th scope="col" className="px-6 py-3">User Id</th>
                      <th scope="col" className="px-6 py-3">Buy Amount</th>
                      <th scope="col" className="px-6 py-3">USDT Amount</th>
                      <th scope="col" className="px-6 py-3">Referral Address</th>
                      <th scope="col" className="px-6 py-3">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.map((row, index) => (
                      <>
                        <tr
                          key={index}
                          className="bg-gray-950 border-b hover:bg-gray-800"
                        >
                          <td className="px-6 py-4 text-primary-gradient  font-bold text-nowrap ">{row.userId}</td>
                          <td className="  px-4 py-4"> <span className='bg-gradient text-white px-6 py-1 rounded-3xl text-nowrap ' >{row.buyAmount}</span> </td>
                          <td className="px-6 py-4">{row.balARZ}</td>
                          <td className="px-6 py-4">{row.referral}</td>
                          <td className="px-6 py-4">{row.createdAt}</td>
                        </tr>
                      </>

                    ))}
                  </tbody>
                </table>

              </div>

              <nav className="flex gap-2 items-center justify-end pt-4" aria-label="Table navigation">
                <button
                  onClick={() => setCurrentPage(currentPage > 1 ? currentPage - 1 : 1)}
                  className="px-3 h-8 text-primary-gradient  font-bold bg-gray-700 border-gray-600 rounded hover:text-white hover:bg-gray-600"
                  disabled={currentPage <= 1}
                >
                  {"<<"}
                </button>

                <div className="inline-flex space-x-2 text-sm">
                  {createPagination().map((page, index) => (
                    <button
                      key={index}
                      onClick={() => handlePageClick(page)}
                      className={`px-3 h-8 border font-bold border-gray-600 rounded ${currentPage === page ? 'bg-gray-500 text-primary-gradient  font-bold' : 'bg-gray-700 text-primary-gradient  font-bold hover:text-white hover:bg-gray-600'
                        }`}
                    >
                      {page}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => setCurrentPage(currentPage < totalPages ? currentPage + 1 : totalPages)}
                  className="px-3 h-8 text-primary-gradient  font-bold bg-gray-700 border-gray-600 rounded hover:text-white hover:bg-gray-600"
                  disabled={currentPage >= totalPages}
                >
                  {">>"}
                </button>
              </nav>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default BuyHistory;
