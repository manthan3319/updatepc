import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from "react-router-dom";
import "../../styles/Dashboard.css";
import logo from "../../assets/arzlogo.png";
import logoarz from  "../../assets/tether-usdt-logo.png";
import usdt from "/usdt01.png";
import refer from "/refer01.png";
import ic1 from "/logoarz.png";
import ic3 from "../../assets/ic3.svg";
import ic4 from "../../assets/ic4.png";
import user from "../../assets/user.png";
import menu from "../../assets/menu.svg";
import BuyAbi from '../utils/BuyAbi.json'
import USDTAbi from '../utils/usdtAbi.json';
import { Web3Button } from '@web3modal/react'
import TokenModal from "../utils/TokenModal";
import { list } from "../utils/tokenlist";
import toast from "react-hot-toast";
import { useAccount } from "wagmi";
import Web3 from "web3";
import './globle.css'
import {
  prepareWriteContract,
  writeContract,
  waitForTransaction,
} from "@wagmi/core";
import axios from 'axios';

const isValid = (regex) => (input) => regex.test(input);
const numberRegex = /^\d*\.?\d*$/;
const isValidNumber = isValid(numberRegex);

const Dashboard = () => {
  const [isActive, setIsActive] = useState(false);
  const navigate = useNavigate();
  const { isConnected, address } = useAccount();
  const BuyAddress = "0xFdDDb5c87e292EFdC3E32f7F2043Ea9F71fbDD83";
  const usdtAddress = "0xc2132D05D31c914a87C6611C10748AEb04B58e8F";
  const [tFundsRaised, settFundsRaised] = useState(0);
  const [walletBal, setwalletBal] = useState(0);

  const webApi = new Web3("https://polygon-bor-rpc.publicnode.com");
  const [data, setData] = useState({
    bnb: "",
    gart: "",
    referralAddress: "",
  });
  const [open, setOpen] = useState(false);
  const [selectedToken, setselectedToken] = useState(list[0]);
  const [approvalDone, setApprovalDone] = useState(false);
  const [tPrice, setTPrice] = useState(false);
  const [buyerData, setBuyerData] = useState(0);
  const [tDirect, settDirect] = useState(0);
  const [tIndirect, settIndirect] = useState(0);

  const [referralLink, setReferralLink] = useState('');
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 3;
  const [loading, setLoading] = useState(true);
  const [datas, setDatas] = useState([]);
  const [userData, setUserData] = useState([]);
  const [refData, setRefData] = useState([]);
  const referralAddress = userData.address;

  // contact us model 
  const [isOpen, setIsOpen] = useState(false);



  const toggleModal = () => {
    setIsOpen(!isOpen);
  };

  const closeModal = () => {
    setIsOpen(false);
  };

  const closeMenu = () => {
    setIsNavVisible(false);
  };

  const handleLogout = async () => {
    try {
      await axios.post('http://localhost:3300/api/logout');
      localStorage.removeItem('token');
      onLogout();
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:3300/api/user', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        setUserData(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching user data:', error);
        setLoading(false);
      }
    };
    fetchUserData();
  }, []);

  useEffect(() => {
    // Generate referral link when component mounts
    generateReferralLink();
  }, []);


  console.log("UserData", userData);

  const generateReferralLink = () => {
    // Generate a unique referral code or link here
    // For simplicity, let's assume it's based on the user's email
    const referralCode = userData.userId; // Using part of the email as a referral code
    setReferralLink(`http://localhost:3300/register?ref=${referralCode}`);
  };


  const [isSaved, setIsSaved] = useState(false);

  console.log("Connectted Wallet", address);
  // console.log("UserData",userData);

  const handleActivate = async () => {
    if (!userData || !address) {
      console.error('User data or wallet address is missing');
      toast.error("User data or wallet address is missing");
      return;
    }

    try {
      // Call connectWallet function
      await connectWallet(address);

      // Call saveContractor function
      await saveContractor();

      // Update state and local storage to indicate data is saved
      setIsSaved(true);
      localStorage.setItem(`isActivated_${userData.walletAddress}`, true);
      toast.success("Data saved successfully");
      window.location.reload();
    } catch (error) {
      console.error('Error:', error);
      toast.error("Failed to save data");
    }
  };


  const connectWallet = async () => {
    const walletAddress = address;
    const token = localStorage.getItem('token');

    try {
      const response = await fetch('http://localhost:3300/api/connectWallet', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ walletAddress })
      });

      const data = await response.json();

      if (response.ok) {
        toast.success('Wallet connected successfully');
      } else {
        if (data.message === 'Wallet address has already been connected') {
          toast.error('This wallet address is already connected to your account');
        } else if (data.message === 'Wallet address is already in use by another user') {
          toast.error('This wallet address is already in use by another user');
        } else {
          toast.error('Failed to connect wallet');
        }
      }
    } catch (error) {
      toast.error('Error connecting wallet: ' + error.message);
    }
  };


  const saveContractor = async () => {
    if (!userData || !userData.walletAddress) {
      console.error('User data or wallet address is missing');
      toast.error("User data or wallet address is missing");
      return;
    }

    const data3 = {
      walletAddress: userData.walletAddress,
      refferralAddress: userData.referralAddress,
    };

    console.log("data", data3);

    try {
      const response = await fetch('http://localhost:3300/api/add', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data3),
      });

      if (!response.ok) {
        const errorDetails = await response.text();
        console.error('Error details:', errorDetails);
        throw new Error('Failed to store data in database');
      }

      const result = await response.json();
      console.log('Success:', result);

      // Update status to active
      await fetch('http://localhost:3300/api/user/updateStatus', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ walletAddress: userData.walletAddress, status: 'active' }),
      });

      localStorage.setItem(`isActivated_${userData.walletAddress}`, true);
      toast.success("Contractor saved successfully");
    } catch (error) {
      console.error('Error:', error);
      toast.error("Failed to save data");
    }
  };


  // console.log("referral link", referralLink);


  //  Contractor save



  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
      return;
    }

    axios.get('http://localhost:3300/api/buys', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
      .then(response => {
        setDatas(response.data);
        setLoading(false);
      })
      .catch(error => {
        console.error('There was an error fetching the data!', error);
        setLoading(false);
      });
  }, [navigate]);

  const toggleSidebar = () => {
    setIsActive(!isActive);
  };




  const copyReferralLink = () => {
    const inviteLink = document.querySelector(".invite");
    const textarea = document.createElement("textarea");
    textarea.value = inviteLink.textContent;
    document.body.appendChild(textarea);
    textarea.select();
    textarea.setSelectionRange(0, 99999);

    document.execCommand("copy");
    document.body.removeChild(textarea);
    alert("Referral link copied to clipboard!");
  };


  useEffect(() => {
    if (isConnected) {
      fetchwalletBal(address);
    }
  }, [isConnected, address]);

  const fetchwalletBal = async (walletAddress) => {
    try {
      const balance = await webApi.eth.getBalance(walletAddress);
      const balanceInEther = webApi.utils.fromWei(balance);
      setwalletBal(balanceInEther);
    } catch (error) {
      console.error('Error fetching wallet balance:', error);
    }
  };

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflowY = 'auto';
      return () => {
        document.body.style.overflowY = 'auto';
      };
    }
  }, [isOpen]);

  useEffect(() => {
    const tFundsRaised = async () => {
      try {
        const buyContract = new webApi.eth.Contract(BuyAbi, BuyAddress);
        const fundsRaised = await buyContract.methods.totalFundsRaised().call();
        settFundsRaised(fundsRaised / 10 ** 6);
      } catch (error) {
        console.error("Error fetching total funds raised:", error);
      }
    };
    tFundsRaised();
  }, []);

  useEffect(() => {
    const tPriceFetch = async () => {
      try {
        const buyContract = new webApi.eth.Contract(BuyAbi, BuyAddress);
        const Rate = await buyContract.methods.tokensPerUSDT().call();
        setTPrice(Rate / 100000);
      } catch (error) {
        console.error("Error fetching total funds raised:", error);
      }
    };
    tPriceFetch();
  }, []);

  useEffect(() => {
    const totalTeam = async () => {
      try {
        const buyContract = new webApi.eth.Contract(BuyAbi, BuyAddress);
        const directTeam = await buyContract.methods.getTotalDirectReferrals(address).call();
        const indirectTeam = await buyContract.methods.getTotalIndirectReferrals(address).call();
        settDirect(directTeam);
        settIndirect(indirectTeam);
      } catch (error) {
        console.error("Error fetching total funds raised:", error);
      }
    };
    totalTeam();
  }, []);

  useEffect(() => {
    const fetchBuyerData = async () => {
      try {
        const buyContract = new webApi.eth.Contract(BuyAbi, BuyAddress);

        // Fetch Buyer struct data from the contract
        const buyer = await buyContract.methods.buyers(address).call();
        setBuyerData(buyer);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching buyer data:', error);
        setLoading(false);
      }
    };

    if (address) {
      fetchBuyerData();
    } else {
      setLoading(false);
    }
  }, [address]);


  const raisedAmount = tFundsRaised;
  const targetAmount = 25000000;
  const pRaised = (raisedAmount / targetAmount) * 100;
  const progressBar = `${pRaised}%`;



  const buyWithUsdt = async () => {

    try {
      let bnbValue = webApi.utils.toWei(data.bnb.toString());
      const usdtAmt = bnbValue / 10 ** 12;
      const bnbValueNumber = Number(usdtAmt);
      const buyTransaction = await prepareWriteContract({
        address: BuyAddress,
        abi: BuyAbi,
        functionName: "buyWithUSDT",
        args: [userData.referralAddress, bnbValueNumber],
        from: address,
      });

      const toastId = toast.loading("Processing Buy Transaction..");
      await writeContract(buyTransaction);

      const buyUSDTAmt = bnbValueNumber / 10 ** 6;
      const buyTokenAmt = (bnbValueNumber * tPrice) / 10 ** 6;
      // Store data in database
      const userDatas = {
        userId: userData.userId,
        email: userData.email,
        buyAmount: buyUSDTAmt,
        balARZ: buyTokenAmt,
        referral: userData.referralAddress,
        walletAddress: address
      };

      const response = await fetch('http://localhost:3300/api/buys', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userDatas),
      });

      if (!response.ok) {
        throw new Error('Failed to store data in database');
      }

      const refData = {
        walletAddress: userData.walletAddress,
        amount: buyUSDTAmt.toString()
      };

      console.log("refData:", refData); // Log the data being sent

      try {
        const response = await fetch('http://localhost:3300/api/addReward', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(refData),
        });

        if (!response.ok) {
          const errorDetails = await response.text();
          console.error('Error details:', errorDetails); // Log the error details from the server
          throw new Error('Failed to store data in database');
        }

        const result = await response.json();
        console.log('Success:', result); // Log the success response

      } catch (error) {
        console.error('Error:', error);
        throw error;
      }

      toast.success("Buy Transaction completed successfully", { id: toastId });
      setData({ bnb: "", gart: "" });

      setTimeout(() => {
        window.location.reload();
      }, 3000);

    } catch (error) {
      toast.error("Something went wrong with the transaction!");
      console.error(error);
    }
  };

  // const saveContractor = async () => {

  //   if (!userData || !userData.walletAddress) {
  //       console.error('User data or wallet address is missing');
  //       toast.error("User data or wallet address is missing");
  //       return;
  //     }

  //     const data3 = {
  //       walletaddress: userData.walletAddress,
  //       referraladdress: userData.referralAddress,
  //     };

  //     console.log("data", data3);

  //     try {
  //       const response = await fetch('http://localhost:3300/api/v1/contractor/add', {
  //         method: 'POST',
  //         headers: {
  //           'Accept': 'application/json',
  //           'Content-Type': 'application/json',
  //         },
  //         body: JSON.stringify(data3),
  //       });

  //       if (!response.ok) {
  //         const errorDetails = await response.text();
  //         console.error('Error details:', errorDetails);
  //         throw new Error('Failed to store data in database');
  //       }

  //       const result = await response.json();
  //       console.log('Success:', result);
  //     } catch (error) {
  //       console.error('Error:', error);
  //     }

  // }






  const approveTransaction = async () => {
    try {
      let bnbValue = webApi.utils.toWei(data.bnb.toString());
      const usdtAmt = bnbValue / 10 ** 12;
      const bnbValueNumber = Number(usdtAmt);
      const approvalTransaction = await prepareWriteContract({
        address: usdtAddress,
        abi: USDTAbi,
        functionName: "approve",
        args: [BuyAddress, bnbValueNumber],
        from: address,
      });

      const toastId = toast.loading("Approving transaction...");
      const hash = await writeContract(approvalTransaction);
      toast.loading("Processing Approval Transaction..", { id: toastId });
      await waitForTransaction(hash);
      toast.dismiss(toastId);
      toast.success("Approval completed successfully");
      setApprovalDone(true);
    } catch (error) {
      toast.error("Something went wrong with the transaction!");
      console.error(error);
    }
  };

  const currentUserData = datas.filter(item => item.userId === userData.userId);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = currentUserData.slice(indexOfFirstItem, indexOfLastItem);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text).then(() => {
      alert('Referral code copied to clipboard!');
    }, (err) => {
      console.error('Could not copy text: ', err);
    });
  };

  return (
     <div className="main-container">
      <div className="wrapper">
        <nav id="sidebar" className={`sidebar ${isActive ? "active" : ""}`}>
          <div className="sidebar-header">
            <img src={logo} alt="" />
            <button
            className='lg:hidden closemenu'
            id="sidebarCollapse"
            onClick={toggleSidebar}
           
          >
           <i class="fa fa-times" aria-hidden="true"></i>
          </button>
            <p className="username"></p>
          </div>

          <ul className="list-unstyled components">
            <div className="user" style={{ paddingBottom: 20 }}>
              <div className=" circle22">
                <img src={user} className="spec22" alt="" />
              </div>
              <p className="username">{userData.username}</p> <br />

            </div>
            <p className="">User ID : {userData.userId}</p>
            <li className="active">
              <a
                href="/dashboard"
                data-toggle="collapse"
                aria-expanded="false"
                className="dropdown-toggle"
              >
                Dashboard
              </a>
            </li>

            <li>
              <a
                href="/buyhistory"
                data-toggle="collapse"
                aria-expanded="false"
                className="dropdown-toggle"
              >
                Buy History
              </a>
            </li>
            <li>
              <a href="/referralhistory"> Referral History</a>
            </li>
            <li>
              <a href="https://arzona-whitepaper.gitbook.io/arzona-whitepaper/">Whitepaper</a>
            </li>
            <li>
              <a href="#">Contract</a>
            </li>
            {/* <li>
              <a href="#">Setting</a>
            </li> */}
            <li>
              {!localStorage.getItem("token") ? (
                <div className="flex gap-4">
                  <Link
                    to={"/login"}
                    className="leading-3 p-3 bg-[#F9DA0A] rounded-md text-[#000000] font-semibold"
                  >
                    Login
                  </Link>
                  <Link
                    to={"/signup"}
                    className="leading-3 p-3 rounded-md bg-[#8484848A] text-white font-semibold"
                  >
                    Sign up
                  </Link>
                </div>
              ) : (
                <button
                  onClick={() => {
                    localStorage.clear();
                    window.location.reload();
                  }}
                  className="leading-3 p-3 rounded-md bg-[#000000] text-white font-semibold"
                >
                  Logout
                </button>
              )}
            </li>

          </ul>
        </nav>

        <div id="content">
          <button
            id="sidebarCollapse"
            onClick={toggleSidebar}
            style={{ backgroundColor: "black" }}
          >
            <img src={menu} alt="" />
          </button>

          
          <br />
          <div className="content1">
            <div className="content01">
              <p className="chead">Welcome to Arzona Staking.</p>
              <p className="cpara">
                Second Round is about to start. Let’s explore it.
              </p>
            </div>
            {isConnected ? (
              <button type="button" onClick={toggleModal} className="connectwallet">
                Bal: {parseFloat(walletBal).toFixed(3)} MATIC
              </button>
            ) : (
              // If wallet is not connected, show connect button
              <button type="button" onClick={toggleModal} className="connectwallet">
                Connect wallet
              </button>
            )}
          </div>
          <br />
          <div className="container1">
            <div className="dashcards">
              <div className="c1circle">
                <img src={ic1} alt="" />
              </div>
              <p className="c1head">
                Total Balance <br />
                <p className="c1data">{buyerData.totalPurchased / 10 ** 6} ARZ</p>
              </p>
            </div>
            <div className="dashcards">
              <div className="c1circle">
                <img className="spec" src={logoarz} alt="" />
              </div>
              <p className="c1head">
                Total Value <br />
                <p className="c1data">{buyerData.totalPurchased / tPrice / 10 ** 6} USDT</p>
              </p>
            </div>
            <div className="dashcards">
              <div className="c1circle">
                <img src={ic3} alt="" />
              </div>
              <p className="c1head">
                Referral Earning <br />
                <p className="c1data">{buyerData.totalReferralRewards / 10 ** 6} USDT</p>
              </p>
            </div>
            <div className="dashcards">
              <div className="c1circle">
                <img className="spec" src={ic4} alt="" />
              </div>
              <p className="c1head">
                Direct/Indirect <br />
                <p className="c1data">{tDirect} / {tIndirect}</p>
              </p>
            </div>
          </div>
          <br />
          <div className="maincontent">
            <div className="contentleft">
              <div className="con1">
                <p className="conhead">
                  Buy Arzona Tokens <br />
                  <p className="conpara">
                    Referral address and name and earning, which level,
                    transferrable hash coding.
                  </p>
                </p>


                <div className="inputdata2">
                  <div className="idleft">
                    <img src={usdt} alt="" />

                    <input
                      className="dashinput"
                      type="text"
                      id="Amount"
                      placeholder="Enter Amount"
                      value={data.bnb}
                      onChange={(e) => {
                        const val = e.target.value
                          .split("")
                          .filter((el) => isValidNumber(el))
                          .join("");
                        setData({
                          ...data,
                          bnb: val,
                          gart: val * tPrice,
                        });
                      }}
                    />

                  </div>
                  {/* <div className="max"></div> */}
                </div>
                <div className="inputdata2">
                  <div className="idleft">
                    <img src={ic1} alt="" />
                    <input
                      className="dashinput"
                      type="text"
                      id="Amount"
                      placeholder="Get Arzona"
                      value={data.gart}
                      onChange={(e) => {
                        const val = e.target.value
                          .split("")
                          .filter((el) => isValidNumber(el))
                          .join("");
                        setData({
                          ...data,
                          gart: val,
                          bnb: val / tPrice,
                        });
                      }}
                    />

                  </div>
                  {/* <div className="max"></div> */}
                </div>
                {/* <div className="inputdata">
                  <div className="idleft">
                    <img src={refer} alt="" />
                    <input
                      className="dashinput"
                      type="text"
                      id="Amount"
                      placeholder="Referral Address"
                      value={data.referralAddress}
                      onChange={(e) => {
                        const val = e.target.value;
                        setData({
                          ...data,
                          referralAddress: val,
                        });
                      }}
                    />

                  </div>
                  <div className="max"></div>
                </div> */}
                <div className="inputdata">
                  <button
                    className="submit"
                    onClick={buyWithUsdt}
                  >
                    Buy Now
                  </button>
                </div>
              </div>
              <div className="con2">
                <p className="conhead">
                  Approve Tokens <br />
                  <p className="conpara" style={{ marginBottom: 10 }}>
                    Welcome to the future of mining with AI tokens. Our platform
                    harnesses the power of artificial intelligence to optimize
                    mining processes and energy efficiency.
                  </p>
                  <div className="inputdata2">
                    <input
                      className="dashinput"
                      type="text"
                      id="Amount"
                      placeholder="Enter Amount"
                      value={data.bnb}
                      onChange={(e) => {
                        const val = e.target.value
                          .split("")
                          .filter((el) => isValidNumber(el))
                          .join("");
                        setData({
                          ...data,
                          bnb: val,
                          gart: val * tPrice,
                        });
                      }}
                    />

                  </div>
                  <div className="inputdata2">
                    <button className="submit"
                      onClick={approveTransaction}
                    >
                      Approve
                    </button>
                  </div>
                  {userData.status !== 'active' && (
                    <div className="inputdata2">
                      <button className="submit"
                        onClick={handleActivate}
                      >
                        Activate
                      </button>
                    </div>
                  )}
                </p>
              </div>
            </div>
            <div className="contentright">
              <div className="refer">
                <div className="referleft">
                  <div className="refer1">
                    <div></div>
                    <p className="referhead">Referral ID</p>
                  </div>
                  <p className="referpara">
                    Welcome to the future of mining with AI tokens. Our platform
                    harnesses the power of artificial intelligence to optimize
                    mining processes and energy efficiency.
                  </p>
                </div>
                <div className="referright">
                  {/* {userData.status !== "inactive" && ( */}
                  <>
                    {/* {userData &&  */}
                    <div className="invite">{userData.userId}</div>
                    {/* } */}
                    <div className="submitrefer" onClick={copyReferralLink}>
                      Copy Referral ID
                    </div>
                  </>
                  {/* )} */}
                </div>
              </div>

              <div className="transaction">
                <p className="transactionhead">Buy history</p>
                <br />
                <div className="tags">

                  <div className="sno transactionsub">User Id</div>
                  <div className="buyamt transactionsub">Buy Amount</div>
                  <div className="usdtamt transactionsub">USDT Amount</div>
                  <div className="refadd transactionsub">Referral Address</div>
                  <div className="refadd transactionsub">Date</div>
                </div>
                {isConnected && currentItems.map((item) => (
                  <div key={item.id} className="tagdiv">
                    <div className="tags">
                      <div className="sno">{item.userId}</div>
                      <div className="buyamt">{item.buyAmount} USDT</div>
                      <div className="usdtamt">{item.balARZ} ARZ</div>
                      <div className="refadd">{item.referral.slice(0, 12)} <button onClick={() => handleCopy(item.referral)} className="copy-btn">
                        ......
                      </button></div>

                      <div className="date">{item.createdAt}</div>
                    </div>
                  </div>
                ))}
                <br />
                <br />
                {isConnected && (
                  <div className="pagination">
                    {Array.from({ length: Math.ceil(data.length / itemsPerPage) }, (_, index) => (
                      <button
                        key={index + 1}
                        onClick={() => paginate(index + 1)}
                        className={`page-link ${currentPage === index + 1 ? 'active' : ''}`}
                      >
                        {index + 1}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <TokenModal
        open={open}
        setOpen={setOpen}
        handleOpen={handleOpen}
        handleClose={handleClose}
        currentChain={selectedToken}
        setCurrentChain={setselectedToken}
        setData={setData}
      />

      {isOpen && (
        <div
          id="popup-modal"
          onClick={closeModal}
          tabIndex="-1"
          className="fixed  h-[100vh] inset-0 z-50  bg-slate-900  bg-opacity-50    "
        >
          <div className="h-[100vh] flex items-center justify-center">
            <div
              onClick={(e) => e.stopPropagation()}
              className="relative h-fit   rounded-3xl shadow bg-gray-900 border-2 border-[--primary-color] bg-opacity-90 "
            >
              <button
                onClick={closeModal}
                type="button"
                className="absolute top-3 end-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                data-modal-hide="popup-modal"
              >
                <svg
                  className="w-3 h-3"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 14 14"
                >
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                  />
                </svg>
                <span className="sr-only">Close modal</span>
              </button>


              <div className=" max-w-[40rem] p-4 md:p-5 text-center">
                <div className='flex gap-3 flex-col items-center justify-center'>

                  <div className="p-4 md:p-5">
                    <p className="text-sm font-normal text-gray-500 dark:text-gray-400">Connect with one of our available wallet providers or create a new one.</p>
                    <ul className="my-4 space-y-3">

                      <Web3Button />
                    </ul>
                    <div>
                      <a href="#" className="inline-flex items-center text-xs font-normal text-gray-500 hover:underline dark:text-gray-400">
                        <svg className="w-3 h-3 me-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                          <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7.529 7.988a2.502 2.502 0 0 1 5 .191A2.441 2.441 0 0 1 10 10.582V12m-.01 3.008H10M19 10a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                        </svg>
                        Why do I need to connect with my wallet?</a>
                    </div>
                  </div>


                </div>
              </div>
            </div>
          </div>

        </div>
      )}
    </div>
  );
};

export default Dashboard;
