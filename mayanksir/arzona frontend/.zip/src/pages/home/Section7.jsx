import React from "react";
import "../../styles/Section7.css";
import s7img1 from "../../assets/s7img1.png";
import s7img2 from "../../assets/s7img2.svg";
import s7img3 from "../../assets/s7img3.svg";
import s7back from "../../assets/s7back.mp4";
import "./globle_responsive.css";
const Section7 = () => {
  return (
    <>
      <div className="section7">
        <video autoPlay muted playsInline loop className="s7video">
          <source src={s7back} />
        </video>
        <div className="overlaytop"></div>
        <div className="overlaybottom"></div>
        <div className="s7main">
          <div>
            <p className="s2smallhead" style={{ width: 200, marginBottom: 30 }}>
              <div className="s2box" style={{ width: 200 }}>
                Ecosystem
              </div>
            </p>
          </div>
          <p className="s3heading">Exploring The Ecosystem Of Arzona</p>
          <div className="s3para" style={{ textAlign: "center" }}>
            The Arzona Ecosystem encompasses two core components: AI Crypto
            Mining and Crypto Farming. Our AI Crypto Mining platform leverages
            machine learning algorithms to enhance mining efficiency and
            profitability. Meanwhile, our Crypto Farm provides a sustainable
            environment for mining operations, ensuring minimal environmental
            impact.
          </div>

          <div className="s7cards">
            <div className="s7card">
              <img src={s7img1} alt="" className="s7img" />
              <div className="s7content">
                <p className="s7head">AI Mining System</p>
                <p className="s7para">
                  Arzona's AI Mining solutions harness cutting-edge artificial
                  intelligence to revolutionize the cryptocurrency mining
                  landscape. By leveraging advanced algorithms, our technology
                  optimizes mining operations for maximum efficiency, reduced
                  energy consumption, and enhanced profitability, paving the way
                  for a sustainable and prosperous future in crypto mining.
                </p>
              </div>
            </div>
            <div className="s7card">
              <img src={s7img2} alt="" className="s7img" />
              <div className="s7content">
                <p className="s7head">Crypto Farm Design</p>
                <p className="s7para">
                  Arzona specializes in designing custom crypto farms that
                  prioritize efficiency, scalability, and cost-effectiveness.
                  With a focus on innovation and industry expertise, Arzona
                  ensures that each tailored solution maximizes mining potential
                  while minimizing operational complexities, setting the stage
                  for long-term success in the crypto market.
                </p>
              </div>
            </div>
            <div className="s7card">
              <img src={s7img3} alt="" className="s7img" />
              <div className="s7content">
                <p className="s7head">Mining Rig</p>
                <p className="s7para">
                  Arzona's Mining Rug service is your go-to solution for
                  fine-tuning mining rigs for peak performance. Leveraging our
                  expertise in hardware optimization, we meticulously configure
                  rigs to achieve optimal hash rates and profitability. With
                  Arzona, miners can stay ahead of the competition, achieving
                  sustainable success in the dynamic world of cryptocurrency
                  mining.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Section7;
