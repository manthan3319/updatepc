import React from "react";
import image1 from "../../assets/image2.png";
import s4icon from "../../assets/s4icon.svg";
import "../../styles/Section4.css";
import harvest from "../../assets/harvest.png";
import image4 from "../../assets/image4.png";
import "./globle_responsive.css";
const Section4 = () => {
  return (
    <>
      <div className="section4">
        <div className="s4main">
          <div className="s4left">
            <p className="s2smallhead" style={{ width: 200 }}>
              <div className="s2box" style={{ width: 200 }}>
                Arzona Mining Rig
              </div>
            </p>
            <p className="s4head">
              Enhancing Rig Performance for Profit Maximization
            </p>
            <p className="s4para">
              Arzona's Mining Rug service fine-tunes mining rigs for peak
              performance, optimizing hash rates and profitability. With expert
              configuration management, miners stay competitive in the evolving
              crypto market.
            </p>
            <div className="s4points">
              <div className="s4pleft">
                <div className="s4d1">
                  <img src={s4icon} alt="" />
                  <p className="s4pdesc">Expert rig optimization</p>
                </div>
                <div className="s4d1">
                  <img src={s4icon} alt="" />
                  <p className="s4pdesc">Peak performance assurance</p>
                </div>
              </div>
              <div className="s4pright">
                <div className="s4d1">
                  <img src={s4icon} alt="" />
                  <p className="s4pdesc">
                    Competitive edge in mining landscape
                  </p>
                </div>
                <div className="s4d1">
                  <img src={s4icon} alt="" />
                  <p className="s4pdesc">Hash rate maximization</p>
                </div>
              </div>
            </div>
          </div>
          <div className="s4right">
            <img src={image4} alt="" />
          </div>
        </div>
        <div className="s4main2">
          <div className="s4left">
            <p className="s2smallhead" style={{ width: 200 }}>
              <div className="s2box" style={{ width: 200 }}>
                Arzona Crypto Farming
              </div>
            </p>
            <p className="s4head">Harvest Profits with Crypto Farming</p>
            <p className="s4para">
              In the future, AI mining systems will transform the industry by
              significantly improving efficiency, safety, and sustainability.
              These systems will leverage advanced algorithms and real-time data
              analytics to optimize extraction processes.
            </p>
            <div className="s4points">
              <div className="s4pleft">
                <div className="s4d1">
                  <img src={s4icon} alt="" />
                  <p className="s4pdesc">Customized farm designs</p>
                </div>
                <div className="s4d1">
                  <img src={s4icon} alt="" />
                  <p className="s4pdesc">Efficiency-driven configurations</p>
                </div>
              </div>
              <div className="s4pright">
                <div className="s4d1">
                  <img src={s4icon} alt="" />
                  <p className="s4pdesc">Scalable infrastructure</p>
                </div>
                <div className="s4d1">
                  <img src={s4icon} alt="" />
                  <p className="s4pdesc">Profit-maximizing strategies</p>
                </div>
              </div>
            </div>
          </div>
          <div className="s4right">
            <img src={harvest} alt="" />
          </div>
        </div>
      </div>
    </>
  );
};

export default Section4;
