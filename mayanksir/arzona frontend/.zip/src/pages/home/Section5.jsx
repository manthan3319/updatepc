import React from "react";
import "../../styles/Section5.css";
import tokenomics from "../../assets/arzonatoke.png";
import "./globle_responsive.css";

const Section5 = () => {
  return (
    <>
      <div className="Blockchain_Ecosystem">
        <div className="sections_new_ecosystem">
          <div className="text-center ecosystem_title">
            <h3>Blockchain Ecosystem</h3>
            <p>Launching Our Blockchain Ecosystem in 1 Year</p>
          </div>
          <div className="ecosystem_contant">
            <div className="ecosystem_card">
              <h2>Comprehensive Ecosystem</h2>
              <p>Our platform will encompass everything from NFTs to hosting new projects, all with minimal network fees</p>
            </div>

            <div className="ecosystem_card">
              <h2>Low Network Fees</h2>
              <p>Efficient consensus mechanisms to keep transaction costs low and encourage widespread use</p>
            </div>

            <div className="ecosystem_card">
              <h2>NFT Marketplace</h2>
              <p>User-friendly interface for minting, buying, and selling NFTs with competitive fees.</p>
            </div>
            <div className="ecosystem_card">
              <h2>Project Hosting</h2>
              <p>Support for new blockchain ventures with incubation, launchpad services, and community engagement</p>
            </div>
            <div className="ecosystem_card">
              <h2>Advanced Security:</h2>
              <p>Robust security protocols and continuous audits to ensure the safety of all participants.</p>
            </div>
          </div>
        </div>
      </div>
      <div className="section5">
        <p className="s5head">Tokenomics</p>
        <p className="s5para">
          The Arzona token (ARZ) is our ecosystem's utility token. It fuels
          transactions, facilitates rewards, and grants access to exclusive
          features and benefits. Holders of ARZ tokens play a vital role in
          shaping the future of AI-driven crypto mining.
        </p>
        <img src={tokenomics} alt="" className="s5img" />
        <div className="utility">
          <p className="s5smallhead">
            <div className="s5box">
              <p>Token Name</p>
              <p>Arzona</p>
            </div>
          </p>
          <p className="s5smallhead">
            <div className="s5box">
              <p>Symbol</p>
              <p>ARZ</p>
            </div>
          </p>
          <p className="s5smallhead">
            <div className="s5box">
              <p>Network</p>
              <p>MATIC</p>
            </div>
          </p>
          <p className="s5smallhead">
            <div className="s5box">
              <p>Decimal</p>
              <p>18</p>
            </div>
          </p>
          <p className="s5smallhead">
            <div className="s5box">
              <p>Supply</p>
              <p>14 Billion</p>
            </div>
          </p>
        </div>
      </div>
    </>
  );
};

export default Section5;
