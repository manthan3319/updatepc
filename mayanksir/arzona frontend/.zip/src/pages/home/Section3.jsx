import React from "react";
import "../../styles/Section3.css";
import carddesign from "../../assets/carddesign.svg";
import s3img01 from "../../assets/01.png";
import "./globle_responsive.css";
const Section3 = () => {
  return (
    <>
      <div className="section3">
        <div className="s3head">
          <p className="s2smallhead">
            <div className="s2box">Features</div>
          </p>
        </div>
        <p className="s3heading">Versatile Features Of Arzona</p>
        <div className="s3para" style={{ textAlign: "center" }}>
        AI-driven mining with autobots: efficient, sustainable, and highly advanced operations.{" "}
        </div>

        <div className="s3carddiv">
          <div className="s3card">
            <img src={carddesign} alt="" className="s3cardimg" />
            <div className="s3content">
              <img
                src={s3img01}
                alt=""
                style={{ width: 52, height: 52, marginBottom: 10 }}
              />
              <p className="cardhead">Blockchain Explorer</p>
              <p className="cardpara">
              Access detailed views of transactions, blocks, addresses, and network activity, along with tools to create and manage custom tokens easily.
              </p>
              <div className="s3btn">Explore Now</div>
            </div>
          </div>
          <div className="s3card">
            <img src={carddesign} alt="" className="s3cardimg" />
            <div className="s3content">
              <img
                src={s3img01}
                alt=""
                style={{ width: 52, height: 52, marginBottom: 10 }}
              />
              <p className="cardhead">Eco-Friendly Practices</p>
              <p className="cardpara">
              Blockchain explorer enables viewing transactions, blocks, addresses, and network, create token  activity.
              </p>
              <div className="s3btn">Explore Now</div>
            </div>
          </div>
          <div className="s3card">
            <img src={carddesign} alt="" className="s3cardimg" />
            <div className="s3content">
              <img
                src={s3img01}
                alt=""
                style={{ width: 52, height: 52, marginBottom: 10 }}
              />
              <p className="cardhead">AI-Powered Mining Automation</p>
              <p className="cardpara">
              Utilize advanced AI algorithms and autobots for optimized, efficient, and automated mining operations.
              </p>
              <div className="s3btn">Explore Now</div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Section3;
