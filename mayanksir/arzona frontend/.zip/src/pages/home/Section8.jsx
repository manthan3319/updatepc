import React from "react";
import s8back from "../../assets/s8video.mp4";
import "../../styles/Section8.css";
import "./globle_responsive.css";
const Section8 = () => {
  return (
    <>
      <div className="section8">
        <video autoPlay muted playsInline loop className="s8video">
          <source src={s8back} />
        </video>
        <div className="s8content"></div>
        <div className="s8con">
          <p className="s2smallhead" style={{ width: 200 }}>
            <div className="s2box" style={{ width: 200 }}>
              Arzona AI Mining
            </div>{" "}
          </p>
          <p className="s8head">
            Leading the Way in AI-Optimized Crypto Mining for More Profitable
            Future
          </p>
          <p className="s8para">
            AI Crypto Mining with Arzona offers several advantages. It improves
            mining efficiency, reduces energy consumption, and maximizes returns
            for miners. Additionally, it contributes to a more sustainable
            mining environment by leveraging advanced technology
          </p>
        </div>
      </div>
    </>
  );
};

export default Section8;
