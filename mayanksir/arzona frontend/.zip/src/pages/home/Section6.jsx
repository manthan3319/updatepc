import React from "react";
import "../../styles/Section6.css";
import roadmap from "../../assets/arzroadmap.svg";
import rm1 from "../../assets/rm1.svg";
import rm2 from "../../assets/rm2.svg";
import rm3 from "../../assets/rm3.svg";
import rm4 from "../../assets/rm4.svg";
import rm5 from "../../assets/rm5.svg";
import "./globle_responsive.css";
const Section6 = () => {
  return (
    <>
      <div className="section6">
        <p className="s5head">Roadmap</p>
        <p className="s5para">
          Arzona is designed to fuel transactions, incentivize participation,
          and foster growth within the platform. The token operates on its
          blockchain infrastructure while also being compatible with the Trade
          Smart Chain, ensuring flexibility and interoperability across
          different networks.
        </p>

        <div className="roadmapcontent">
          <div className="rmleft">
            <div className="rmdiv">
              <p className="s6head p1">Phase 1</p>
              <p className="s6head2 p1">Presale and AI Farm Development</p>
              <div className="points">
                <div className="circle"></div>
                <p className="pointname">
                  Conduct a presale of 4 billion ARZ tokens to fund AI farm
                  development.
                </p>
              </div>
              <div className="points">
                <div className="circle"></div>
                <p className="pointname">
                  Build and launch the Arzona AI mining farm, integrating AI
                  algorithms for enhanced efficiency.
                </p>
              </div>
            </div>
            <div className="rmdiv2"></div>
            <div className="rmdiv">
              <p className="s6head p3">Phase 3</p>
              <p className="s6head2 p3">AI Mining Optimization</p>
              <div className="points">
                <div className="circle"></div>
                <p className="pointname">
                  Implement AI mining optimization strategies to maximize mining
                  output and profitability.
                </p>
              </div>
              <div className="points">
                <div className="circle"></div>
                <p className="pointname">
                  Continuously refine AI algorithms based on real-time data and
                  market trends.
                </p>
              </div>
            </div>
            <div className="rmdiv2"></div>
          </div>
          <div className="rmcenter">
            <img src={roadmap} alt="" className="rmimg" />
          </div>
          <div className="rmright">
            <div className="rmdiv" style={{ height: 125 }}></div>
            <div className="rmdiv2">
              <p className="s6head p2">Phase 2</p>
              <p className="s6head2 p2">
                Token Integration and Ecosystem Growth
              </p>

              <div className="points">
                <div className="circle"></div>
                <p className="pointname">
                  Integrate ARZ tokens into the Arzona ecosystem for utility and
                  governance purposes.
                </p>
              </div>
              <div className="points">
                <div className="circle"></div>
                <p className="pointname">
                  Facilitate ecosystem growth by developing decentralized
                  applications (dApps), staking mechanisms, and other
                  value-added services.
                </p>
              </div>
            </div>
            <div className="rmdiv"></div>
            <div className="rmdiv2">
              <p className="s6head p4">Phase 4</p>
              <p className="s6head2 p4">Community Expansion and Partnerships</p>
              <div className="points">
                <div className="circle"></div>
                <p className="pointname">
                  Expand the Arzona community through marketing initiatives,
                  events, and educational programs.
                </p>
              </div>
              <div className="points">
                <div className="circle"></div>
                <p className="pointname">
                  Forge strategic partnerships with industry leaders, exchanges,
                  and technology providers to enhance ecosystem capabilities.
                </p>
              </div>
            </div>
            <div className="rmdiv"></div>
          </div>
        </div>

        <div className="mobilecontent">
          <div className="mobileroad">
            <img src={rm1} alt="" />
            <div className="rmdiv">
              <p className="s6head p1">Phase 1</p>
              <p className="s6head2 p1">Presale and AI Farm Development</p>
              <div className="mobilepoints">
                <div className="circle"></div>
                <p className="pointname">
                  Conduct a presale of 4 billion ARZ tokens to fund AI farm
                  development.
                </p>
              </div>
              <div className="mobilepoints">
                <div className="circle"></div>
                <p className="pointname">
                  Build and launch the Arzona AI mining farm, integrating AI
                  algorithms for enhanced efficiency.
                </p>
              </div>
            </div>
          </div>
          <div className="mobileroad">
            <img src={rm2} alt="" />
            <div className="rmdiv">
              <p className="s6head p2">Phase 2</p>
              <p className="s6head2 p2">
                Token Integration and Ecosystem Growth
              </p>

              <div className="mobilepoints">
                <div className="circle"></div>
                <p className="pointname">
                  Integrate ARZ tokens into the Arzona ecosystem for utility and
                  governance purposes.
                </p>
              </div>
              <div className="mobilepoints">
                <div className="circle"></div>
                <p className="pointname">
                  Facilitate ecosystem growth by developing decentralized
                  applications (dApps), staking mechanisms, and other
                  value-added services.
                </p>
              </div>
            </div>
          </div>
          <div className="mobileroad">
            <img src={rm3} alt="" />
            <div className="rmdiv">
              <p className="s6head p3">Phase 3</p>
              <p className="s6head2 p3">AI Mining Optimization</p>
              <div className="points">
                <div className="circle"></div>
                <p className="pointname">
                  Implement AI mining optimization strategies to maximize mining
                  output and profitability.
                </p>
              </div>
              <div className="points">
                <div className="circle"></div>
                <p className="pointname">
                  Continuously refine AI algorithms based on real-time data and
                  market trends.
                </p>
              </div>
            </div>
          </div>
          <div className="mobileroad">
            <img src={rm4} alt="" />
            <div className="rmdiv2">
              <p className="s6head p4">Phase 4</p>
              <p className="s6head2 p4">Community Expansion and Partnerships</p>
              <div className="points">
                <div className="circle"></div>
                <p className="pointname">
                  Expand the Arzona community through marketing initiatives,
                  events, and educational programs.
                </p>
              </div>
              <div className="points">
                <div className="circle"></div>
                <p className="pointname">
                  Forge strategic partnerships with industry leaders, exchanges,
                  and technology providers to enhance ecosystem capabilities.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Section6;
