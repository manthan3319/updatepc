import React from "react";
import "../../styles/Section2.css";
import s2video from "../../assets/s2video.mp4";
import "./globle_responsive.css";
const Section2 = () => {
  return (
    <>
      <div className="section2">
        <div className="s2left">
          <p className="s2smallhead">
            <div className="s2box">About Us</div>
          </p>
          <p className="s2heading">Exploring the crypto universe with Arzona</p>
          <p className="s2para">
            Arzona envisions a future where AI-driven crypto mining sets new
            benchmarks for efficiency and sustainability. Their mission is to
            leverage artificial intelligence to optimize mining operations,
            minimize energy consumption, and maximize returns for miners and
            investors. This forward-thinking approach aligns with industry
            trends and underscores a commitment to driving innovation and
            responsible practices within the cryptocurrency mining sector.
          </p>
          <a href="" className="s2button">
            Explore Now
          </a>
        </div>
        <div className="s2right">
          <video autoPlay muted playsInline loop className="s3video">
            <source src={s2video} />
          </video>
        </div>
      </div>
    </>
  );
};

export default Section2;
