import React from "react";

const Topnavbar = () => {
  return <div>Topnavbar</div>;
};

export default Topnavbar;
