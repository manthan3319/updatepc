import React from "react";
import "../styles/Footer.css";
import logo from "../assets/arzonalogo.png";
import social1 from "../assets/social1.png";
import social2 from "../assets/social2.png";
import social3 from "../assets/social3.png";
import social4 from "../assets/social4.png";

const Footer = () => {
  return (
    <>
      <div className="footer">
        <div className="footerdiv">
          <div className="fd">
            <img src={logo} alt="" className="fimg" />
            <p className="fdesc">
              Arzona pioneers AI technology, creating immersive worlds to
              redefine digital exploration and inspire future innovation.
            </p>
          </div>
          <div className="fd">
            <p className="fdhead">UseCases</p>
            <p className="fpoints">Ecosystem</p>
            <p className="fpoints">AI Mining</p>
            <p className="fpoints">Farm Design</p>
          </div>
          <div className="fd">
            <p className="fdhead">Resources</p>
            <p className="fpoints">Whitepaper</p>
          </div>
          <div className="fd">
            <p className="fdhead">Company</p>
            <p className="fpoints">About Us</p>
            <p className="fpoints">FAQ</p>
            <p className="fpoints">Teams</p>
            <p className="fpoints">Contact Us</p>
          </div>
        </div>

        <div className="footermedia">
          <p>Follow Us :</p>
          <img src={social1} alt="" />
          <img src={social2} alt="" />
          <img src={social3} alt="" />
          <img src={social4} alt="" />
          <img src={social2} alt="" />
        </div>
        <div className="fdetails">
          <p>Privacy Policy</p>
          <p>Terms & Conditions</p>
          <p>Sitemap</p>
          <p>Legal</p>
        </div>
        <p className="copyright">@2024 All Rights Reserved</p>
      </div>
    </>
  );
};

export default Footer;
