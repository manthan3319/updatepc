import React, { useState } from "react";
import "./Login.css";
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';
import Loading from "./Loading";

const Forget = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [userId, setUserId] = useState('');
  const [error, setError] = useState('');
  const [otp, setOtp] = useState('');
  const [showOtpInput, setShowOtpInput] = useState(false);
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);




  return (
    <>
      <div className="Login">
        <form style={{ borderRadius: 20 }} onSubmit={handleSubmit}>
          <div className="row">
            <div className="heading">
              <div className="logdata">
                <h1 className="text text-large">Reset Password</h1>
                <Link
                  to="/"
                  className="text text-large"
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    flexDirection: "row",
                    fontSize: "1rem",
                  }}
                >
                  <ion-icon name="chevron-back-circle-outline"></ion-icon> Go
                  Back
                </Link>
              </div>
            </div>

            <div className="row">
            <label htmlFor="address">User Id</label>
            <input
              type="text"
              placeholder="Enter User Id"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
            />
          </div>

            <label htmlFor="email">Enter email </label>
            <input
              type="email"
              name="email"
              autoComplete="off"
              placeholder="email@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          
          {showOtpInput && (
            <div className="row">
              <label htmlFor="otp">OTP</label>
              <input
                type="text"
                id="otp"
                placeholder="Enter OTP"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
              />
            </div>
          )}
          {showOtpInput && (
          <div className="row">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              placeholder="Enter New Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          )}

          <button type="submit" className="sub">
            {isLoading ? <Loading /> : showOtpInput ? 'Change Password' : 'Send OTP'}
          </button>
        </form>
      </div>
    </>
  );
};

export default Forget;
