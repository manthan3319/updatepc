import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';
import toast from "react-hot-toast";
import apple from "../assets/apple.png";
import facebook from "../assets/facebook.png";
import google from "../assets/google.png";
import Loading from "./Loading";
import "./Login.css";

const Login = () => {
  const navigate = useNavigate();
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await axios.post('http://localhost:3000/api/login-with-userid', { userId, password });

      if (response.data.token) {
        const { token, userId, username } = response.data;
        localStorage.setItem('token', token);
        localStorage.setItem('userId', userId);
        localStorage.setItem('username', username);
        toast.success('Login successful! Redirecting to dashboard...');
        window.location.reload();
        navigate('/dashboard');
      } else {
        setError('Invalid User Id or password');
      }
    } catch (error) {
      console.error('Login error:', error);

      if (error.response && error.response.status === 404) {
        setError('User not found');
        toast.error('User not found');
      } else {
        setError('An error occurred while logging in');
        toast.error('An error occurred while logging in');
      }
    } finally {
      setLoading(false);
    }
  };

  return (

    <div className="Login">
      <form style={{ borderRadius: 20 }} onSubmit={handleSubmit}>
        <div className="row">
          <div className="heading">
            <div className="logdata">
              <h1 className="text text-large">Sign In</h1>
              <Link
                to="/"
                className="text text-large"
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  flexDirection: "row",
                  fontSize: "1rem",
                }}
              >
                <ion-icon name="chevron-back-circle-outline"></ion-icon> Go Back
              </Link>
            </div>
            <p className="text text-normal">
              New user?{" "}
              <span>
                <Link to="/register" className="text text-links">
                  Create an account
                </Link>
              </span>
            </p>
          </div>
          <label htmlFor="userId">Enter User Id</label>
          <input
            type="text"
            name="userId"
            placeholder="Enter userId"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            required
          />
        </div>
        <div className="row">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            name="password"
            placeholder="Enter Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <Link
          to={"/forget"}
          className="leading-3 p-3 bg-[#F9DA0A] rounded-md text-[#000000] font-semibold"
        >
          Forget Password
        </Link>
        <button className="sub" type="submit" disabled={loading}>
          {loading ? <Loading /> : 'Login'}
        </button>

      </form>
    </div>
  );
};

export default Login;
