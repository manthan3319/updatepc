import React, { useState, useEffect } from 'react';
import "./Login.css";
import { Link, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import Loading from "./Loading";

const Register = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [referredBy, setReferredBy] = useState(141414);
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [showOtpInput, setShowOtpInput] = useState(false);
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);



  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      if (!showOtpInput) {
        const response = await fetch('http://localhost:3000/api/signup', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ username, email, referredBy, password }),
        });
        if (response.ok) {
          setShowOtpInput(true);
          const data = await response.json();
          console.log(data);
          setMessage(data.message);
          toast.success('OTP sent');
        } else {
          const data = await response.json();
          setMessage(data.error || 'An error occurred while processing your request.');
          toast.error('An error occurred while processing your request.');
        }
      } else {
        const response = await fetch('http://localhost:3300/api/verifyOtp', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ email, otp }),
        });
        if (response.ok) {
          const data = await response.json();
          setMessage(data.message);
          toast.success('User ID sent by mail');
          navigate("/login");
        } else {
          const data = await response.json();
          setMessage(data.error || 'An error occurred while processing your request.');
          toast.error('An error occurred while processing your request.');
        }
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('An error occurred while processing your request.');
      toast.error('An error occurred while processing your request.');
    } finally {
      setIsLoading(false); 
    }
  };

  return (
    <>
      <div className="Login">
        <form style={{ borderRadius: 20 }} onSubmit={handleSubmit}>
          <div className="row">
            <div className="heading">
              <div className="logdata">
                <h3 className="text text-large">Create A New Account</h3>
                <Link
                  to="/"
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    flexDirection: "row",
                    fontSize: "0.9rem",
                    color: "black",
                    fontWeight: 500,
                  }}
                >
                  {" "}
                  <ion-icon name="chevron-back-circle-outline"></ion-icon> Go
                  Back
                </Link>
              </div>
              <p className="text text-normal">
                Already have an account?
                <span>
                  <Link to="/login" className="text text-links">
                    Log In
                  </Link>
                </span>
              </p>
            </div>
          </div>
          <div className="row">
            <label htmlFor="username">User Name</label>
            <input
              type="text"
              placeholder="User Name"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div className="row">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="row">
            <label htmlFor="address">Referral Id (Optional)</label>
            <input
              type="text"
              placeholder="Referral Address"
              value={referredBy}
              onChange={(e) => setReferredBy(e.target.value)}
            />
          </div>
          <div className="row">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {showOtpInput && (
            <div className="row">
              <label htmlFor="otp">OTP</label>
              <input
                type="text"
                placeholder="Enter OTP"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
              />
            </div>
          )}
          <button type="submit" className="sub">
          {isLoading ? <Loading /> : showOtpInput ? 'Verify OTP' : 'Create Account'}
          </button>
        </form>
      </div>
    </>
  );
};

export default Register;
