import React, { useState } from "react";
import "./Login.css";
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';
import toast from "react-hot-toast";
import Loading from "./Loading";

const Forget = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [userId, setUserId] = useState('');
  const [otp, setOtp] = useState('');
  const [showOtpInput, setShowOtpInput] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (!showOtpInput) {
        // Send OTP
        await sendOTP();
      } else {
        // Change password
        await changePassword();
      }
    } catch (error) {
      console.error('Forget password error:', error);
      toast.error('Forget password error:', error);
    }finally {
      setLoading(false);
    }
  };

  const sendOTP = async () => {
    try {
      const response = await axios.post('http://localhost:3300/api/forgot-password', { userId });

      if (response.status === 200) {
        setShowOtpInput(true);
        toast.success('OTP sent successfully');
      } else {
        toast.error('Failed to send OTP');
      }
    } catch (error) {
      console.error('Send OTP error:', error);
      toast.error('Forget password error:', error);
    }
  };

  const changePassword = async () => {
    try {
      const response = await axios.put('http://localhost:3300/api/reset-password', { userId, otp, newPassword });
  
      if (response.status === 200) {
        setShowOtpInput(true);
        toast.success('Password changed successfully');
        navigate('/login'); // Redirect to login page
      } else {
        toast.error('Invalid OTP');
      }
    } catch (error) {
      console.error('Change password error:', error);
      toast.error('An error occurred while changing the password');
    }
  };
  


  return (
    <>
      <div className="Login">
        <form style={{ borderRadius: 20 }} onSubmit={handleSubmit}>
          <div className="row">
            <div className="heading">
              <div className="logdata">
                <h1 className="text text-large">Reset Password</h1>
                <Link
                  to="/"
                  className="text text-large"
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    flexDirection: "row",
                    fontSize: "1rem",
                  }}
                >
                  <ion-icon name="chevron-back-circle-outline"></ion-icon> Go
                  Back
                </Link>
              </div>
            </div>

            <div className="row">
            <label htmlFor="address">User Id</label>
            <input
              type="text"
              placeholder="Enter User Id"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              required
            />
          </div>

            <label htmlFor="email">Enter email </label>
            <input
              type="email"
              name="email"
              autoComplete="off"
              placeholder="email@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          
          {showOtpInput && (
            <div className="row">
              <label htmlFor="otp">OTP</label>
              <input
                type="text"
                name="otp"
                placeholder="Enter OTP"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                required
              />
            </div>
          )}
          {showOtpInput && (
          <div className="row">
            <label htmlFor="newPassword">Password</label>
            <input
              type="text"
              name="newPassword"
              placeholder="Enter New Password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              required
            />
          </div>
          )}

          <button type="submit" className="sub">
            {loading ? <Loading /> : showOtpInput ? 'Change Password' : 'Send OTP'}
          </button>
        </form>
      </div>
    </>
  );
};

export default Forget;
