import "./App.css";
import Home from "./pages/home/Home";

import { BrowserRouter, Route, Routes } from "react-router-dom";
import Presale from "./pages/presale/Presale";
import BuyHistory from "./pages/presale/BuyHistory";
import ReferralHistory from "./pages/presale/ReferralHistory";
import Login from "./component/Login";
import Forget from "./component/Forget";
import Register from "./component/Register";
import {
  ProtectedAuthPages,
  ProtectedPages,
} from "./pages/presale/ProtectedPages";
import Dashboard from "./pages/presale/Dashboard";
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/presale" element={<Presale />} />
          <Route element={<ProtectedAuthPages />}>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forget" element={<Forget />} />
          </Route>
          <Route element={<ProtectedPages />}>
            <Route
              loader={async () => {
                fetchAndStoreUserInfo();
                return null;
              }}
              path="/dashboard"
              element={<Dashboard />}
            />
            <Route path="/buyhistory" element={<BuyHistory />} />
            <Route path="/referralhistory" element={<ReferralHistory />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
