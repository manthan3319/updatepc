import React from "react";
import "./App.css";
import Connect from "./components/connect";
import Saidbar from "./components/saidbar";
import Staking from "./pages/Staking";
import Deshbord from "./components/deshbord";
import LevelRewards from "./pages/LevelRewards";
import DailyRewards from "./pages/DailyRewards";
import Withdrawal from "./pages/withdrawal";
import TeamBonus from "./pages/TeamBonus";
import { Route, Routes } from "react-router-dom";
import DailyIncome from "./pages/DailyIncome";
import DirectTeam from "./pages/DirectTeam";
import TotalTeam from "./pages/TotalTeam";
import Team from "./pages/Team";
import Ranks from "./pages/Ranks"
import Rewards from "./pages/Rewards";
import Salary from "./pages/Salary";
import AffiliatePlan from "./pages/AffiliatePlan"
import AlertPilot from "./pages/AlertPilot"
import Markets from "./pages/Markets"
import Support from "./pages/Support"

function App() {
  return (
    <React.Fragment>
      <div className="container_main">
        <Saidbar />
        <Connect className="connect_wallet" />
      </div>
      <Routes>
        <Route path="/" element={<Deshbord />} />
        <Route path="/staking" element={<Staking />} />
        <Route path="/level-rewards" element={<LevelRewards />} />
        <Route path="/daily-rewards" element={<DailyRewards />} />
        <Route path="/withdrawal-list" element={<Withdrawal />} />
        <Route path="/team-bonus" element={<TeamBonus />} />
        <Route path="/daily-income" element={<DailyIncome />} />
        <Route path="/direct-team" element={<DirectTeam />} />
        <Route path="/total-team" element={<TotalTeam />} />
        <Route path="/Team" element={<Team />} />
        <Route path="/Ranks" element={<Ranks />} />
        <Route path="/Rewards" element={<Rewards />} />
        <Route path="/Salary" element={<Salary />} />
        <Route path="/AffiliatePlan" element={<AffiliatePlan />} />
        <Route path="/AlertPilot" element={<AlertPilot />} />
        <Route path="/Markets" element={<Markets />} />
        <Route path="/Support" element={<Support />} />
      </Routes>
    </React.Fragment>
  );
}

export default App;
