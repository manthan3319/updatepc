import React, { useState, useRef } from "react";
import { Link, useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import depositicon from "../image/sidebar-icon/save-money (1).png"
import Walleticon from "../image/sidebar-icon/wallet.png";
import team from "../image/sidebar-icon/team.png";
import Ranks from "../image/sidebar-icon/ranks.png";
import Rewards from "../image/sidebar-icon/reward.png";
import Salary from "../image/sidebar-icon/salary.png";
import AffiliatePlan from "../image/sidebar-icon/AffiliatePlan.png";
import WhitePaper from "../image/sidebar-icon/WhitePaper.png";
import AlertPilot from "../image/sidebar-icon/AlertPilot.png";
import Markets from "../image/sidebar-icon/Markets.png";
import Support from "../image/sidebar-icon/Support.png";
import staking from "../image/sidebar-icon/staking.png";
import Dashbord from "../image/sidebar-icon/dashboard.png";
import afflitepdf from '../pdf/Smart Profit X.pdf';

const Saidbar = () => {
  let navigate = useNavigate();
  const [activeLink, setActiveLink] = useState("/");
  const location = useLocation();
  const navbarCollapseRef = useRef(null);

  const handleLinkClick = (path) => {
    setActiveLink(path);
    if (navbarCollapseRef.current && navbarCollapseRef.current.classList.contains('show')) {
      navbarCollapseRef.current.classList.remove('show');
    }
  };

  const AffiliatePlanePdf = async () => {
    try {
      const response = await fetch("../pdf/Smart Profit X.pdf");
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
  
      const link = document.createElement("a");
      link.href = url;
      link.download = "Smart Profit X.pdf";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading PDF:", error);
    }
  };

  const AffiliatePlanePdf2 = async () => {
    try {
      const response = await fetch("../pdf/Smart ProfitX White Paper (2).pdf");
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
  
      const link = document.createElement("a");
      link.href = url;
      link.download = "Smart ProfitX White Paper (2).pdf";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Error downloading PDF:", error);
    }
  };


  return (
    <div>
      <div className="sidebar">
        <div className="navbarnone">
          <nav className="navbar navbar-expand-md">
            <div className="logo">
              <div className="togglebtn">
                <button
                  className="navbar-toggler"
                  type="button"
                  data-toggle="collapse"
                  data-target="#collapsibleNavbar"
                >
                  <span className="navbar-toggler-icon">
                    <i className="fa fa-bars" aria-hidden="true"></i>
                  </span>
                </button>
              </div>
              <div className="logos_menu">
                <h4 className="desktop-logo">
                  <img src="/logonew.png" alt="Logo" />
                </h4>
                <h4 className="mobile-logo">
                  <img src="/logonew.png" alt="Logomobile" />
                </h4>
              </div>
            </div>
            <div className="menubar">
              <div className="menucontant">
                <div
                  className="collapse navbar-collapse"
                  id="collapsibleNavbar"
                  ref={navbarCollapseRef}
                >
                  <Link
                    to="/"
                    className={location.pathname === "/" ? "active" : ""}
                    onClick={() => handleLinkClick("/")}
                  >
                    <img width={"20"} src={Dashbord} alt="dasicon" />
                    Dashboard
                  </Link>
                  <Link
                    to="staking"
                    className={location.pathname === "/staking" ? "active" : ""}
                    onClick={() => handleLinkClick("staking")}
                  >
                    <img width={"20"} src={staking} alt="dasicon" />
                    Staking
                  </Link>
                  <Link
                    to="daily-income"
                    className={
                      location.pathname === "/daily-income" ? "active" : ""
                    }
                    onClick={() => handleLinkClick("daily-income")}
                  >
                    <img width={"20"} src={depositicon} alt="dasicon" />
                    Deposit
                  </Link>
                  <Link
                    to="total-team"
                    className={
                      location.pathname === "/total-team" ? "active" : ""
                    }
                    onClick={() => handleLinkClick("total-team")}
                  >
                    <img width={"20"} src={Walleticon} alt="dasicon" />
                    Wallet
                  </Link>
                  <Link
                    to="/Team"
                    className={location.pathname === "/Team" ? "active" : ""}
                    onClick={() => handleLinkClick("/Team")}
                  >
                    <img width={"20"} src={team} alt="rewicon" />
                    Team
                  </Link>
                  <Link
                    to="/Ranks"
                    className={location.pathname === "/Ranks" ? "active" : ""}
                    onClick={() => handleLinkClick("/Ranks")}
                  >
                    <img width={"20"} src={Ranks} alt="rewicon" />
                    Ranks
                  </Link>
                  {/* <Link
                    to="/Rewards"
                    className={
                      location.pathname === "/Rewards" ? "active" : ""
                    }
                    onClick={() => handleLinkClick("/Rewards")}
                  >
                    <img width={"20"} src={Rewards} alt="rewicon" />
                    Rewards
                  </Link> */}
                  <Link
                    to="/Salary"
                    className={location.pathname === "/Salary" ? "active" : ""}
                    onClick={() => handleLinkClick("/Salary")}
                  >
                    <img width={"20"} src={Salary} alt="rewicon" />
                    Salary
                  </Link>
                  <Link
                    className={location.pathname === '/AffiliatePlan' ? 'active' : ''}
                    href={afflitepdf}
                    download="Smart_Profit_X.pdf"
                    onClick={() => AffiliatePlanePdf("/AffiliatePlan")}
                  >
                    <img width={"20"} src={AffiliatePlan} alt="rewicon" />
                    Affiliate Plan
                  </Link>
                  <Link
                    className={location.pathname === '/AffiliatePlan' ? 'active' : ''}
                    href={afflitepdf}
                    download="Smart_Profit_X.pdf"
                    onClick={() => AffiliatePlanePdf2("/AffiliatePlan")}
                  >
                    <img width={"20"} src={WhitePaper} alt="rewicon" />
                    White Paper
                  </Link>
                  <Link
                    to="/AlertPilot"
                    className={
                      location.pathname === "/AlertPilot" ? "active" : ""
                    }
                    onClick={() => handleLinkClick("/AlertPilot")}
                  >
                    <img width={"20"} src={AlertPilot} alt="rewicon" />
                    Alert Pilot
                  </Link>
                  <Link
                    to="/Markets"
                    className={location.pathname === "/Markets" ? "active" : ""}
                    onClick={() => handleLinkClick("/Markets")}
                  >
                    <img width={"20"} src={Markets} alt="rewicon" />
                    Markets
                  </Link>
                  <Link
                    to="/Support"
                    className={location.pathname === "/Support" ? "active" : ""}
                    onClick={() => handleLinkClick("/Support")}
                  >
                    <img width={"20"} src={Support} alt="rewicon" />
                    Support
                  </Link>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>
  );
};

export default Saidbar;
