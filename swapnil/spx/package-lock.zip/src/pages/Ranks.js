import React from "react";
import { useEffect, useState } from "react";
import {
  useSDK,
  useContract,
  useAddress,
  useContractRead,
} from "@thirdweb-dev/react";
import { ethers } from "ethers";
import moment from "moment";
import "./page.css";
import Slider from "react-slick";
import { MdKeyboardArrowRight } from "react-icons/md";
const Ranks = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const address = useAddress();
  const sdk = useSDK();

  const { contract } = useContract(
    "0x7d2291988b4f8d3fed0c6aefa131c39586fcb88a"
  );
  const { data: userCounts, isLoading: isUserCountsLoading } = useContractRead(
    contract,
    "UserCounts",
    [address]
  );

  const getData = async () => {
    try {
      setLoading(true);
      const contract1 = await sdk.getContract(
        "0x7d2291988b4f8d3fed0c6aefa131c39586fcb88a"
      );
      let len = Number(userCounts.buyCount.toString());
      let details = [];

      for (let i = 0; i < len; i++) {
        const data = await contract1.call("userBuys", [address, i]);
        let parent = data.parent;
        let amount = parseFloat(
          ethers.utils.formatUnits(data.amount.toString())
        ).toFixed(2);
        let currRate = parseFloat(
          ethers.utils.formatUnits(data.currentRate.toString())
        ).toFixed(7);
        let date = moment
          .unix(data.dateTime.toString())
          .format("DD-MM-YYYY HH:mm:ss");

        let Data = [parent, amount, currRate, date];
        details.push(Data);
      }
      setData(details);
      console.log(data);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!isUserCountsLoading) {
      getData();
    }
  }, [isUserCountsLoading, address]);

  const [stakedData, setStakedData] = useState(null);
  useEffect(() => {
    fetch(`https://backend.smartprofitx.io/user/get-reward?walletId=${address}`)
      .then((response) => response.json())
      .then((data) => {
        setStakedData(data.data);
        console.log(data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, [address]);

  console.log(stakedData);

  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };

  return (
    <React.Fragment>
      <div className="content">
        <div className="container mt-5">
          <div className="parchage_main">
            <div className="page_title">
              {/* <h1> DailyIncome details</h1> */}
              <p>Ranks Overview</p>
            </div>
            <div className="slider_real">
              <Slider {...settings}>
                <div class="card card1">
                  <span class="small-text">
                    Rank & Rewards <MdKeyboardArrowRight />
                  </span>

                  <div className="line_down_div">
                    <div>
                      <div class="title">Investor Rank</div>
                      <div class="title title_new">0/10000</div>
                    </div>
                    <div className="icon_title">
                      <div>
                        <img className="icon_" src="/investor.png" />
                      </div>
                    </div>
                  </div>

                  <hr className="hr_line" />

                  <div className="line_down_div">
                    <span class="desc">Direct Referral: 3</span>
                    <span class="desc">Rewards: 150$(Watch)</span>
                  </div>
                  <hr className="dotted_hr" />
                  <div className="line_down_div">
                    <span class="desc w_half">Direct Business: 1000$</span>
                    <span class="desc w_half recruitment">
                      Team Business: 10000$
                    </span>
                  </div>
                </div>
                <div class="card card2">
                  <span class="small-text">
                    Rank & Rewards <MdKeyboardArrowRight />
                  </span>
                  <div className="line_down_div">
                    <div>
                      <div class="title">Silver Rank</div>
                      <div class="title title_new">0/20000</div>
                    </div>
                    <div className="icon_title">
                      <div>
                        <img className="icon_" src="/silver.png" />
                      </div>
                    </div>
                  </div>
                  <hr className="hr_line" />

                  <div className="line_down_div">
                    <span class="desc">Direct Referral: 6</span>
                    <span class="desc">Rewards: 300$(Ipad)</span>
                  </div>
                  <hr className="dotted_hr" />
                  <div className="line_down_div">
                    <span class="desc w_half">Direct Business: 3000$</span>

                    <span class="desc w_half recruitment">
                      Team Business: 20000$
                    </span>
                  </div>
                </div>
                <div class="card card3">
                  <span class="small-text">
                    Rank & Rewards <MdKeyboardArrowRight />
                  </span>

                  <div className="line_down_div">
                    <div>
                      <div class="title">Gold Rank</div>
                      <div class="title title_new">0/30000</div>
                    </div>
                    <div className="icon_title">
                      <div>
                        <img className="icon_" src="/gold.png" />
                      </div>
                    </div>
                  </div>

                  <hr className="hr_line" />

                  <div className="line_down_div">
                    <span class="desc">Direct Referral: 8</span>
                    <span class="desc">Rewards: 800$(Iphone)</span>
                  </div>
                  <hr className="dotted_hr" />
                  <div className="line_down_div">
                    <span class="desc w_half">Direct Business: 5000$</span>

                    <span class="desc w_half recruitment">
                      Team Business: 30000$
                    </span>
                  </div>
                </div>
                <div class="card card4">
                  <span class="small-text">
                    Rank & Rewards <MdKeyboardArrowRight />
                  </span>

                  <div className="line_down_div">
                    <div>
                      <div class="title">Diamond Rank</div>
                      <div class="title title_new">0/10000</div>
                    </div>
                    <div className="icon_title">
                      <div>
                        <img className="icon_" src="/diamond.png" />
                      </div>
                    </div>
                  </div>
                  <hr className="hr_line" />

                  <div className="line_down_div">
                    <span class="desc">3 Gold Rank</span>
                    <span class="desc">Rewards: 1500$(Macbook)</span>
                  </div>
                  <hr className="dotted_hr" />
                  <div className="line_down_div">
                    <span class="desc">3 Gold Ranks in Different Legs </span>
                  </div>
                </div>
                <div class="card card5">
                  <span class="small-text">
                    Rank & Rewards <MdKeyboardArrowRight />
                  </span>
                  <div className="line_down_div">
                    <div>
                      <div class="title">Blue Diamond Rank</div>
                      <div class="title title_new">0/10000</div>
                    </div>
                    <div className="icon_title">
                      <div>
                        <img className="icon_" src="/blue_diamond.png" />
                      </div>
                    </div>
                  </div>
                  <hr className="hr_line" />

                  <div className="line_down_div">
                    <span class="desc">3 Diamond Rank</span>
                    <span class="desc">Rewards: 3000$(Dubai Trip)</span>
                  </div>
                  <hr className="dotted_hr" />
                  <div className="line_down_div">
                    <span class="desc">3 Diamond Rank in Different Legs</span>
                  </div>
                </div>
                <div class="card card6">
                  <span class="small-text">
                    Rank & Rewards <MdKeyboardArrowRight />
                  </span>

                  <div className="line_down_div">
                    <div>
                      <div class="title">Platinum Rank</div>
                      <div class="title title_new">0/10000</div>
                    </div>
                    <div className="icon_title">
                      <div>
                        <img className="icon_" src="/platinum.png" />
                      </div>
                    </div>
                  </div>
                  <hr className="hr_line" />

                  <div className="line_down_div">
                    <span class="desc">3 Blue Diamond Rank</span>
                    <span class="desc">Rewards: 10000$(Car)</span>
                  </div>
                  <hr className="dotted_hr" />
                  <div className="line_down_div">
                    <span class="desc">3 Blue Diamond Rank in Different Legs</span>
                  </div>
                </div>
                <div class="card card7">
                  <span class="small-text">
                    Rank & Rewards <MdKeyboardArrowRight />
                  </span>

                  <div className="line_down_div">
                    <div>
                      <div class="title">Ambassador Rank</div>
                      <div class="title title_new">0/10000</div>
                    </div>
                    <div className="icon_title">
                      <div>
                        <img className="icon_" src="/ambass.png" />
                      </div>
                    </div>
                  </div>
                  <hr className="hr_line" />

                  <div className="line_down_div">
                    <span class="desc">3 Platinum Rank</span>
                    <span class="desc">Rewards: 20000$(Rolex)</span>
                  </div>
                  <hr className="dotted_hr" />
                  <div className="line_down_div">
                    <span class="desc">3 Platinum Rank in Different Legs</span>
                  </div>
                </div>
                <div class="card card8">
                  <span class="small-text">
                    Rank & Rewards <MdKeyboardArrowRight />
                  </span>
                  <div className="line_down_div">
                    <div>
                      <div class="title">Ambassador Plus Rank</div>
                      <div class="title title_new">0/10000</div>
                    </div>
                    <div className="icon_title">
                      <div>
                        <img className="icon_" src="/ambass_plus.png" />
                      </div>
                    </div>
                  </div>

                  <hr className="hr_line" />

                  <div className="line_down_div">
                    <span class="desc">3 Ambassador Rank</span>
                    <span class="desc">Rewards: 40000$ (Benz C -Class)</span>
                  </div>
                  <hr className="dotted_hr" />
                  <div className="line_down_div">
                    <span class="desc">3 Ambassador rank in Different Legs</span>
                  </div>
                </div>
                <div class="card card9">
                  <span class="small-text">
                    Rank & Rewards <MdKeyboardArrowRight />
                  </span>

                  <div className="line_down_div">
                    <div>
                      <div class="title">Global Ambassador Rank</div>
                      <div class="title title_new">0/10000</div>
                    </div>
                    <div className="icon_title">
                      <div>
                        <img className="icon_" src="/investor.png" />
                      </div>
                    </div>
                  </div>
                  <hr className="hr_line" />
                  <div className="line_down_div">
                    <span class="desc">3 Ambassador Plus Rank</span>
                    <span class="desc">Rewards: 80000$(Flat)</span>
                  </div>
                  <hr className="dotted_hr" />
                  <div className="line_down_div">
                    <span class="desc">
                      3 Ambassador Plus Rank in Different Legs
                    </span>
                  </div>
                </div>
              </Slider>
            </div>
            <div className="parchage_table">
              <table className="table">
                <thead>
                  <tr>
                    <th>S. No</th>
                    <th className="date_table">Amount</th>
                    <th>Reward</th>
                    <th>Wallet Id</th>

                    <th>Time</th>
                  </tr>
                </thead>
                <tbody>
                  {stakedData?.length > 0 ? (
                    stakedData.map((rowData, index) => (
                      <React.Fragment key={index}>
                        <tr>
                          <td>{index + 1}</td>
                          <td>{rowData.amount.toFixed(2)}</td>
                          <td>{rowData.rewards}</td>
                          <td>{rowData.walletId}</td>

                          <td className="whitespace-nowrap">
                            {new Date(rowData.createdAt).toLocaleString(
                              "en-US",
                              {
                                day: "2-digit",
                                month: "2-digit",
                                year: "numeric",
                                hour: "2-digit",
                                minute: "2-digit",
                                hour12: true,
                              }
                            )}
                          </td>
                        </tr>
                      </React.Fragment>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="4">No Data Found</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default Ranks;
