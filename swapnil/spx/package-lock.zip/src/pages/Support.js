import React from "react";
import commingson from '../image/support.jpeg'

const Support = () => {
 

  return (
    <React.Fragment>
     <div className="content">
        <div className="centered-container">
          <img src={commingson} alt="coming soon" className="coming-soon-img coming-soon-img2" />
        </div>
      </div>
    </React.Fragment>
  );
};

export default Support;
