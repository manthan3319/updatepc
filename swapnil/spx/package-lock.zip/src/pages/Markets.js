import React from "react";
import "./page.css";
import commingson from '../image/commingsoon.jpg'

const Markets = () => {
  

  return (
    <React.Fragment>
      <div className="content">
        <div className="centered-container">
          <img src={commingson} alt="coming soon" className="coming-soon-img" />
        </div>
      </div>
    </React.Fragment>
  );
};

export default Markets;
