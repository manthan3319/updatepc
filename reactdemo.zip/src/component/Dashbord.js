import React from 'react'

const Dashbord = () => {
  return (
    <div>
      Dashbord
    </div>
  )
}

export default Dashbord
