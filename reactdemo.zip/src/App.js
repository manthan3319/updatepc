import React from 'react'
import { Route,  Routes } from 'react-router-dom';
import Dashbord from "../src/component/Dashbord";
import Navbar from "../src/component/Navbar"

const App = () => {
  return (
    <React.Fragment>
      <Navbar></Navbar>
       <Routes>
          <Route path="/" element={<Dashbord />} />
       </Routes>
    </React.Fragment>
  )
}

export default App
